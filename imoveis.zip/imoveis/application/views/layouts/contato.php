<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>

<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
        <a class="navbar-brand" href="#"><i class="fa fa-paw"></i> PET-SHOP</a>
            
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
                
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-lg-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo site_url('main/index') ?>">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#servicos">Serviços</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#passaros">Pássaros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#produto-elenco">Produtos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contato</a>
                    </li>

                </ul>    
            </div>
        </div>
    </nav>
</header>

<!-- SECTION CONTACT -->
<section class="contact" id="contato">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="headerText text-center">
                    <h2 data-aos="fade-up" data-aos-delay="0" data-aos-duration="0">Entre em contato</h2>
                    <p data-aos="fade-up" data-aos-delay="0" data-aos-duration="0">Lorem, ipsum dolor 
                        sit amet consectetur adipisicing elit.
                    </p>
                </div>
            </div>
        </div>
        <div class="row clearfix" data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">
            <div class="offset-sm-2 col-sm-8">
                <form action="<?php echo site_url('main/insert_message') ?>" method="post">
                    <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="text-nome" class="form-control" placeholder="Seu nome" required>
                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" name="text-email" class="form-control" placeholder="Sua email" required>
                    </div>
                    <div class="form-group">
                        <label for="">Telefone</label>
                        <input type="text"  name="text-telefone" class="form-control" placeholder="Seu telefone" id="telefone" required>
                    </div>
                    <div class="form-group">
                        <label for="">Message</label>
                        <textarea class="form-control" placeholder="Deixa uma mensagem" name="text-message" id="" cols="30" rows="10" required></textarea>
                    </div>
                    <div class="form-group">
                        <button class="btn btnD1">Enviar</button>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
</section>



<!-- FOOTER -->
<footer class="mb">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <ul class="sci">
                    <!-- Use fontawesome -->
                    <li><a href="#"><i class="fa fa-facebook"></i> </a> </li>
                    <li><a href="#"><i class="fa fa-twitter"></i> </a> </li>
                    <li><a href="#"><i class="fa fa-google-plus"></i> </a> </li>
                    <li><a href="#"><i class="fa fa-instagram"></i> </a> </li>
                    <li><a href="#"><i class="fa fa-youtube"></i> </a> </li>
                    
                </ul>
                <p class="cpryt">
                    @ Copyright 2019 Pet-Shop | Template by <a href="#"> Anthonio Lior </a> 
                </p>
            </div>
        </div>
    </div>
</footer>