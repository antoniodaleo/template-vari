<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- HEADER -->
<header>
     <!-- Nav bar contatto -->
    <nav class="navbar navbar-dark bg-dark"> 
        <a class="navbar-brand" href="#"><i class="fa fa-phone-square"></i> (85)9 8860-1287</a>  
        <ul class="nav justify-content-end">
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-facebook"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-instagram"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-youtube"></i></a>
            </li>
        </ul>
        <ul class="nav justify-content-end">
            <li class="nav-item">
                <a class="nav-link active" href="#"></a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn btn-primary" href="#" ><i class="fa fa-sign-in"></i> Area cliente</a>
            </li> 
            <li class="nav-item">
                <a class="nav-link active pl-6" href="#"><i class="fa fa-envelope-square"></i> Contato</a>
            </li>         
        </ul>     
    </nav>
    <!-- Nav bar centrale -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand logo" href="#">Imoveis</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item ">
                <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Serviços</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Aluguel</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Venda</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Blog</a>
            </li>
        </ul>
    </div>
  </nav>
</header>
<main>
    <div class="jumbotron jumbotron-fluid banner">
        <div class="container">
            <h1 class="display-4 text-white">Compra o seu sonho</h1>
            <p class="lead text-white">Confira os imoveis conosco</p>
        </div>
    </div>
    <!-- Titolo e inizio delle foto  -->
    <div class="container">
        <div class="col-sm-12">
            <h3 class="text-center">Aluguel e Vendas de Imovéis</h3>
        </div>

        <div class="row mt-3">
            <div class="col-sm-4 mt-1">
                <div class="card">
                    <img class="card-img-top" src="<?php echo base_url('assets/img/casa-3.jpg') ?>" alt="Card image cap">
                    <div class="card-body">
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 mt-1">
                <div class="card">
                    <img class="card-img-top" src="<?php echo base_url('assets/img/casa-2.jpg') ?>" alt="Card image cap">
                    <div class="card-body">
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 mt-1">
                <div class="card">
                    <img class="card-img-top" src="<?php echo base_url('assets/img/casa-3.jpg') ?>" alt="Card image cap">
                    <div class="card-body">
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-sm-4 mt-1">
                <div class="card">
                    <img class="card-img-top" src="<?php echo base_url('assets/img/casa-3.jpg') ?>" alt="Card image cap">
                    <div class="card-body">
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 mt-1">
                <div class="card">
                    <img class="card-img-top" src="<?php echo base_url('assets/img/casa-2.jpg') ?>" alt="Card image cap">
                    <div class="card-body">
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 mt-1">
                <div class="card">
                    <img class="card-img-top" src="<?php echo base_url('assets/img/casa-3.jpg') ?>" alt="Card image cap">
                    <div class="card-body">
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


</main>

<footer>

</footer>

