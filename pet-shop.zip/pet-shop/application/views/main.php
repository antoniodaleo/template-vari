<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- HEADER -->
<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
        <a class="navbar-brand" href="#"><i class="fa fa-paw"></i> PET-SHOP</a>
            
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
                
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-lg-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#home">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#servicos">Serviços</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#passaros">Pássaros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#produto-elenco">Produtos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo site_url('main/contato') ?>">Contato</a>
                    </li>

                </ul>    
            </div>
        </div>
    </nav>
</header>

<!-- BANNER -->
<div class="jumbotron jumbotron-fluid height100p banner" id="home">
    <div class="container h100">
        <div class="contentBox h100">
            <div>
                <!-- Successo submit -->
                <?php if(isset($debug)): ?>
                    <div class="alert alert-success" role="alert" id="messaggio" >
                        <?php echo $debug;  ?>
                    </div>
                <?php endif; ?>

                <h1 data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">OS MELHORES PRODUTOS PARA CACHORRO</h1>
                <p data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">Vem conhecer a nossa loja </p>
            </div>
        </div>
    </div>
</div>

<!-- SERVICES AREA -->
<section class="sec1" id="servicos">
    <div class="container">
        <div class="row">
            <div class="offset-sm-2 col-sm-8">
                <div class="headerText text-center">
                    <h2 data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000"><i class="fa fa-paw"></i> Serviços</h2>
                    <p data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-4">
                <div class="placeBox" data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/tosa.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>Banho e Tosa <br><span>Competência e responsabilidade para deixar os pets lindos e bem cuidados. Nosso banho e tosa possui profissionais treinados para prestar serviços com a maior excelência possível.</span></h3>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="placeBox" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/banner-3.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>Hospedagem <br><span>Competência e responsabilidade para deixar os pets lindos e bem cuidados. Nosso banho e tosa possui profissionais treinados para prestar serviços com a maior excelência possível.</span></h3>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="placeBox" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/loja.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>Loja <br><span>Competência e responsabilidade para deixar os pets lindos e bem cuidados. Nosso banho e tosa possui profissionais treinados para prestar serviços com a maior excelência possível.</span></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- PRODUTOS AREA --> 
<section class="sec2" id="passaros">
    <div class="container h100">
        <div class="contentBox h100">
            <div>
                <h1 data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000"><i class="fas fa-feather-alt"></i> PRODUTOS PARA PÁSSAROS</h1>
                <p data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                </p>
                <a href="#" class="btn btnD1" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">Leia mais</a>
            </div>
        </div>
    </div>
</section>


<!-- SECTION BLOG -->
<section class="blog" id="produto-elenco">
    <div class="container">
        <div class="row">
            <div class="offset-sm-2 col-sm-8">
                <div class="headerText">
                    <h2 data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">VETRINA</h2>
                    <p data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                        Produtos para cachorro e gatos. 
                    </p>
                
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/pro-3.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Ração Royal Canin Mini Adult para Cães Adultos de 
                            Raças Pequenas com 10 Meses ou mais de Idade</h1>
                        <p class="font-italic">ROYAL CANIN</p>
                        <p><span class="badge badge-success">R$ 49,00</span></p>
                       
                        <a href="#" class="btn btnD2">Detalhes</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/pro-4.png') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Ração Royal Canin Mini Adult para Cães Adultos de 
                        Raças Pequenas com 10 Meses ou mais de Idade</h1>
                        <p class="font-italic">ROYAL CANIN</p>
                        <p><span class="badge badge-success">R$ 49,00</span></p>
                
                        <a href="#" class="btn btnD2">Detalhes</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/pro-3.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Ração Royal Canin Mini Adult para Cães Adultos de 
                        Raças Pequenas com 10 Meses ou mais de Idade</h1>
                        <p class="font-italic">ROYAL CANIN</p>
                        <p><span class="badge badge-success">R$ 49,00</span></p>
                
                        <a href="#" class="btn btnD2">Detalhes</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/pro-5.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Ração Royal Canin Mini Adult para Cães Adultos de 
                        Raças Pequenas com 10 Meses ou mais de Idade</h1>
                        <p class="font-italic">ROYAL CANIN</p>
                        <p><span class="badge badge-success">R$ 49,00</span></p>
                
                        <a href="#" class="btn btnD2">Detalhes</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/pro-12.png') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Ração Royal Canin Mini Adult para Cães Adultos de 
                        Raças Pequenas com 10 Meses ou mais de Idade</h1>
                        <p class="font-italic">ROYAL CANIN</p>
                        <p><span class="badge badge-success">R$ 49,00</span></p>
                
                        <a href="#" class="btn btnD2">Detalhes</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/pro-12.png') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Ração Royal Canin Mini Adult para Cães Adultos de 
                        Raças Pequenas com 10 Meses ou mais de Idade</h1>
                        <p class="font-italic">ROYAL CANIN</p>
                        <p><span class="badge badge-success">R$ 49,00</span></p>
                
                        <a href="#" class="btn btnD2">Detalhes</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/pro-11.png') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Ração Royal Canin Mini Adult para Cães Adultos de 
                        Raças Pequenas com 10 Meses ou mais de Idade</h1>
                        <p class="font-italic">ROYAL CANIN</p>
                        <p><span class="badge badge-success">R$ 49,00</span></p>
                
                        <a href="#" class="btn btnD2">Detalhes</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/pro-10.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Ração Royal Canin Mini Adult para Cães Adultos de 
                        Raças Pequenas com 10 Meses ou mais de Idade</h1>
                        <p class="font-italic">ROYAL CANIN</p>
                        <p><span class="badge badge-success">R$ 49,00</span></p>
                
                        <a href="#" class="btn btnD2">Detalhes</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SECTION CONTACT -->
<section class="contact" id="contato">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="headerText text-center">
                    <h2 data-aos="fade-up" data-aos-delay="0" data-aos-duration="0">Entre em contato</h2>
                    <p data-aos="fade-up" data-aos-delay="0" data-aos-duration="0">Lorem, ipsum dolor 
                        sit amet consectetur adipisicing elit.
                    </p>
                </div>
            </div>
        </div>
        <div class="row clearfix" data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">
            <div class="offset-sm-2 col-sm-8">
                <form action="<?php echo site_url('main/insert_message') ?>" method="post">
                    <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="text-nome" class="form-control" required>

                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" name="text-email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Telefone</label>
                        <input type="text"  name="text-telefone" class="form-control" id="telefone" required>
                    </div>
                    <div class="form-group">
                        <label for="">Message</label>
                        <textarea class="form-control" name="text-message" id="" cols="30" rows="10" required></textarea>
                    </div>
                    <div class="form-group">
                        <button class="btn btnD1">Enviar</button>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer class="mb">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <ul class="sci">
                    <!-- Use fontawesome -->
                    <li><a href="#"><i class="fa fa-facebook"></i> </a> </li>
                    <li><a href="#"><i class="fa fa-twitter"></i> </a> </li>
                    <li><a href="#"><i class="fa fa-google-plus"></i> </a> </li>
                    <li><a href="#"><i class="fa fa-instagram"></i> </a> </li>
                    <li><a href="#"><i class="fa fa-youtube"></i> </a> </li>
                    
                </ul>
                <p class="cpryt">
                    @ Copyright 2019 Pet-Shop | Template by <a href="#"> Anthonio Lior </a> 
                </p>
            </div>
        </div>
    </div>
</footer>

