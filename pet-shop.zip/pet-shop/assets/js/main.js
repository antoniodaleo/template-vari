
$('#messaggio').delay(2000).fadeOut('slow');